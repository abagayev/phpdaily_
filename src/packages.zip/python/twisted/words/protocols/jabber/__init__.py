# -*- test-case-name: twisted.words.test -*-
# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.


"""
Twisted Jabber: Jabber Protocol Helpers
"""
