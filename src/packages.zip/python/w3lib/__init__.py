__version__ = "1.22.0"
version_info = tuple(int(v) if v.isdigit() else v
                     for v in __version__.split('.'))
